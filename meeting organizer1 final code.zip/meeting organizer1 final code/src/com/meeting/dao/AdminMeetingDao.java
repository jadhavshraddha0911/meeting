package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.MeetDetails;


public class AdminMeetingDao {

	
public static List<MeetDetails> getAllDetails()
{
	Logger log=Logger.getLogger(ViewDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	List<MeetDetails> list=new ArrayList<MeetDetails>();
	
	try{
		PreparedStatement ps=con.prepareStatement("select * from meetDetails");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			MeetDetails e=new MeetDetails();
			e.setRno(rs.getInt(1));
			e.setMdate(rs.getString(2));
			e.setStime(rs.getString(3));
			e.setEtime(rs.getString(4));
			e.setConfirm(rs.getString(5));
			
			list.add(e);
		}
		con.close();
	}catch(Exception e)
	{
		log.fatal(e);
		}
	
	return list;
}
}

