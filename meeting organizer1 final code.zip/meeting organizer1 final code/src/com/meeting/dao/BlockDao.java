package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.ConfirmBean;


public class BlockDao {
	
public static List<ConfirmBean> getAllMess()
{
	Logger log=Logger.getLogger(ViewDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	List<ConfirmBean> list=new ArrayList<ConfirmBean>();
	
	try{
		
		PreparedStatement ps=con.prepareStatement("select * from confirm");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			ConfirmBean e=new ConfirmBean();
			e.setRoomno(rs.getInt(1));
			e.setStatus(rs.getString(2));
			
			
			list.add(e);
		}
		con.close();
	}catch(Exception e)
	{
		log.fatal(e);;
		}
	
	return list;
}
}

