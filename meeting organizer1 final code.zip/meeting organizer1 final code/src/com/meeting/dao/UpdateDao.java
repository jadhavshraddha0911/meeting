package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.RoomBean;

public class UpdateDao {
	
public static int update(RoomBean e){
	Logger log=Logger.getLogger(UpdateDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	int status1=0;
	try{
		
		PreparedStatement ps=con.prepareStatement("update room set roomname=?,status=? where roomno=?");
		
		ps.setString(1,e.getRoomname());
		ps.setString(2,e.getStatus());
		ps.setInt(3,e.getRoomno());
		
		status1=ps.executeUpdate();
		
		con.close();
	}catch(Exception ex){log.fatal(ex);}
	
	return status1;
}
}