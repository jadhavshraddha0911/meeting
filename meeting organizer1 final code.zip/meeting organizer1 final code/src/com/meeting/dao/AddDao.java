package com.meeting.dao;

import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.RoomBean;

import java.sql.*;
public class AddDao {

	public static int save(RoomBean rb){
		Logger log=Logger.getLogger(AddDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		 Connection con=Connect.getConnection();
		 log.info(con);
		int status=0;
		try{

			PreparedStatement ps=con.prepareStatement("insert into room(roomno,roomname,status) values (?,?,?)");
			ps.setInt(1,rb.getRoomno());
			ps.setString(2,rb.getRoomname());
			ps.setString(3,rb.getStatus());
			ResultSet rs=ps.executeQuery();

			con.close();
		}catch(Exception ex){

log.fatal(ex);
			}
		
		return status;
	}
}
		