

package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.RoomBean;

public class SearchDao {


public static List<RoomBean> search(int roomno){
	Logger log=Logger.getLogger(DeleteDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	List<RoomBean> list=new ArrayList<RoomBean>();

	try {
		PreparedStatement ps=con.prepareStatement("select * from room where roomno=?");
		ps.setInt(1,roomno);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			RoomBean e=new RoomBean();
			e.setRoomno(rs.getInt(1));
			
			e.setRoomname(rs.getString(2));
			e.setStatus(rs.getString(3));
			
			list.add(e);
		}
		con.close();
	}catch(Exception e)
	{
	log.fatal(e);
		}
	
	return list;
}
}

