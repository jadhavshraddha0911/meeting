package com.meeting.dao;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;

import java.sql.*;

	public class MeetingDao {

		
		public static boolean checkData(String user,String pass) {
			Logger log=Logger.getLogger(MeetingDao.class);
			 PropertyConfigurator.configure("log4j.properties");
			 Connection con=Connect.getConnection();
			 log.info(con);
			
			PreparedStatement ps;
			try {
				ps = con.prepareStatement("select * from meeting where username=? and password=?");
				ps.setString(1,user);
				ps.setString(2,pass);
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {
					return true;
				}
			} catch (SQLException e) {
				
				log.fatal(e);
			}

			return false;
			
		}

}
