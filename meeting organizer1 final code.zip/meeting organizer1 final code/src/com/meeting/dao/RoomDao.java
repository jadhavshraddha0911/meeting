package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;




import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;

@WebServlet("/RoomDao")
public class RoomDao extends HttpServlet {

    
	public static int delete(int roomno){
		Logger log=Logger.getLogger(RoomDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		 Connection con=Connect.getConnection();
		 log.info(con);
		int status=0;
		try{

			PreparedStatement ps=con.prepareStatement("delete from room where roomno=?");
			ps.setInt(1,roomno);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){
			log.fatal(e);
			}
		
		
		return status;
	}}

