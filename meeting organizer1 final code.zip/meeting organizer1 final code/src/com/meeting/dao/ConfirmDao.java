package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.ConfirmBean;


public class ConfirmDao {

	public static int save(ConfirmBean cb){
		Logger log=Logger.getLogger(ConfirmDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		 Connection con=Connect.getConnection();
		 log.info(con);
		int status=0;
		try{
			
			PreparedStatement ps=con.prepareStatement("insert into confirm(roomno,status) values (?,?)");
			ps.setInt(1, cb.getRoomno());
			ps.setString(2, cb.getStatus());
			
			ResultSet rs=ps.executeQuery();

			con.close();
		}catch(Exception ex){log.fatal(ex);}
		
		return status;
	}
}
