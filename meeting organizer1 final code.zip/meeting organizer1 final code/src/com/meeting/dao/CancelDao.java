package com.meeting.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;

public class CancelDao {

	

public static int cancel(String roomno){
	Logger log=Logger.getLogger(DeleteDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	int status=0;
	try{
		
		PreparedStatement ps=con.prepareStatement("delete from meetdetails where roomno=?");
		ps.setString(1,roomno);
		status=ps.executeUpdate();
		
		con.close();
	}catch(Exception e){log.fatal(e);}
	
	return status;
}
}