package com.meeting.dao;

import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.servletss.Connect;
import com.virtusa.bean.MeetDetails;


import java.sql.*;
public class MeetingDeatilsDao {

	
	public static int save(MeetDetails mt){
		Logger log=Logger.getLogger(AddDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		 Connection con=Connect.getConnection();
		 log.info(con);
		int status=0;
		try{
			
			PreparedStatement ps=con.prepareStatement("insert into meetdetails(roomno,meetdate,startime,endtime,confirm) values (?,?,?,?,?)");
			ps.setInt(1, mt.getRno());
			ps.setString(2, mt.getMdate());
			ps.setString(3, mt.getStime());
			ps.setString(4, mt.getEtime());
			ps.setString(5, mt.getConfirm());
			ResultSet rs=ps.executeQuery();

			con.close();
		}catch(Exception ex){log.fatal(ex);}
		
		return status;
	}
	
	
	
	

public static int room(int id){
	Logger log=Logger.getLogger(DeleteDao.class);
	 PropertyConfigurator.configure("log4j.properties");
	 Connection con=Connect.getConnection();
	 log.info(con);
	int status=0;
	try{

		PreparedStatement ps=con.prepareStatement("select  * from room where roomno=?");
		ps.setInt(1,id);
		status=ps.executeUpdate();
		
		con.close();
	}catch(Exception e){log.fatal(e);;}
	
	return status;
}
}
	