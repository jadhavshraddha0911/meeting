package com.meeting.service;


import com.meeting.dao.MeetingDao;

public class MeetingService {

		public int login(String l,String m)
		{
			if(MeetingDao.checkData(l, m))
					{
				         return 1;
					}
			else
			{
				return 0;
			}
		}
		
		
	}



