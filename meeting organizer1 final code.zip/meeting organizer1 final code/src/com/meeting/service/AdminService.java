package com.meeting.service;

import com.meeting.dao.AdminDao;

public class AdminService {
	public int login(String l,String m)
	{
		if(AdminDao.checkData(l, m))
				{
			         return 1;
				}
		else
		{
			return 0;
		}
	}
	
	
}

