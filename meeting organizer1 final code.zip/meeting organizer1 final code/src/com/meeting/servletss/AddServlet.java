package com.meeting.servletss;


import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.AddDao;
import com.sun.istack.internal.logging.Logger;
import com.virtusa.bean.RoomBean;
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


Logger log=Logger.getLogger(AddServlet.class);
PropertyConfigurator.configure("log4j.properties");
		PrintWriter out=response.getWriter();
		
		
         String rno=request.getParameter("roomno");
		int n=Integer.parseInt(rno);
		String rname=request.getParameter("roomname");
		String stat=request.getParameter("status");
		
		RoomBean r=new RoomBean();
          r.setRoomno(n);
		r.setRoomname(rname);
		r.setStatus(stat);
		
		int status1=0;
				status1=AddDao.save(r);
				
		if(status1>=0){
			log.info("Record saved successfully");
			out.println("<p>Record saved successfully!</p>");

		}else{
			out.println("Sorry! unable to save record");
		}
				out.close();
	}

}
