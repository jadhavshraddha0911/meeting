
package com.meeting.servletss;
import org.apache.log4j.Logger;

import java.io.IOException;
import org.apache.log4j.PropertyConfigurator;


import java.io.PrintWriter;  
  
  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;



import com.meeting.service.AdminService;






@WebServlet("/AdServlet")
  
public class AdServlet extends HttpServlet { 
	static final Logger logger = Logger.getLogger(AdServlet.class);

	  @Override
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
		  Logger log=Logger.getLogger(AdServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
    
    PrintWriter out = response.getWriter(); 


	PropertyConfigurator.configure("C:\\Users\\admin\\Documents\\workspace-sts-3.9.9.RELEASE\\meeting organizer1\\src\\log4j.properties");
	logger.debug("Sample debug message");
	logger.info("Sample info message");
	logger.warn("Sample warn message");
	logger.error("Sample error message");
	logger.fatal("Sample fatal message");
 
          
    String n=request.getParameter("username");  
    String p=request.getParameter("password");  
       AdminService as=new AdminService();  
      int r=as.login(n,p);
	if(r!=0)
	{
		response.sendRedirect("adservicehtml.html");
	}
	else
	{
		out.println("invalid details");
		
	}
    out.close();  
    }  
}  