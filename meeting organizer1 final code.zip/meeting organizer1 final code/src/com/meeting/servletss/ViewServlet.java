package com.meeting.servletss;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.ViewDao;
import com.virtusa.bean.RoomBean;
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	  @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  Logger log=Logger.getLogger(ViewServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='add.html'>Add New room</a>");
		out.println("<h1>room List</h1>");
		
		List<RoomBean> list=ViewDao.getAllRooms();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>roomno</th><th>roomname</th><th>status</th></tr>");
		for(RoomBean e:list){
			out.print("<tr><td>"+e.getRoomno()+"</td><td>"+e.getRoomname()+"</td><td>"+e.getStatus()+"</td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
