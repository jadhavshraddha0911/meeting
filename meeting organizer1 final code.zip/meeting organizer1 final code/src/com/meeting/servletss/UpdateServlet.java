package com.meeting.servletss;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.UpdateDao;
import com.virtusa.bean.RoomBean;
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	  @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  Logger log=Logger.getLogger(UpdateServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		PrintWriter out=response.getWriter();
		
		String roomno=request.getParameter("rno");
		int id=Integer.parseInt(roomno);

		String roomname=request.getParameter("rname");
		String status=request.getParameter("stat");
		
		RoomBean e=new RoomBean();
		
		e.setRoomno(id);

		e.setRoomname(roomname);
		e.setStatus(status);
		int status1=UpdateDao.update(e);
		if(status1>0){
			out.println("updated successfully");

		}else{
			out.println("The entered room number does not exist");
		}
		
		out.close();
	}

}
