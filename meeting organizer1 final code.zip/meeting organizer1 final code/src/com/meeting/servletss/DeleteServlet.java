package com.meeting.servletss;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.PrintWriter;


import com.meeting.dao.DeleteDao;
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger log=Logger.getLogger(DeleteServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		PrintWriter out=response.getWriter();
		String rid=request.getParameter("roomno");

		int status=0;
		status=DeleteDao.delete(rid);
		
		if(status>0)
		{
			out.println("<p>Record deleted successfully!</p>");
		}
		else{
			out.println("Sorry! room number does not exist");
		}
		

	out.close();
	}
}
