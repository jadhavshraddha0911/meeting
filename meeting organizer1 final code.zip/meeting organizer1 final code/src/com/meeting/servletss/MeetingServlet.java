package com.meeting.servletss;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.AdminMeetingDao;

import com.virtusa.bean.MeetDetails;



@WebServlet("/MeetingServlet")
public class MeetingServlet extends HttpServlet {
	 public static int a;
	 String status;
	 @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Logger log=Logger.getLogger(MeetingServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<h1>Meeting Details List</h1>");
		
		
		List<MeetDetails> list=AdminMeetingDao.getAllDetails();
		
		out.print("<table border='1' width='100%'");
		
		out.print("<tr><th>room no</th><th>date</th><th>start time</th><th>end time</th><th>confirmation</th></tr>");
		for(MeetDetails e:list){

			out.print("<tr><td>"+e.getRno()+"</td><td>"+e.getMdate()+"</td><td>"+e.getStime()+"</td><td>"+e.getEtime()+"</td><td>"+e.getConfirm()+"</td></tr>");
		}
		out.print("</table>");
		out.print("</form>");

		out.close();
	}
}