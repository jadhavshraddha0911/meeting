package com.meeting.servletss;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.MeetingDeatilsDao;
import com.virtusa.bean.MeetDetails;

@WebServlet("/MeetDetailsServlet")
public class MeetDetailsServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger log=Logger.getLogger(MeetDetailsServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		PrintWriter out=response.getWriter();
		String rno=request.getParameter("roomno");
		int r=Integer.parseInt(rno);
         String date=request.getParameter("meetdate");
	
		String sttime=request.getParameter("startime");
	
		String etime=request.getParameter("endtime");
	
		String confirm=request.getParameter("confirm");
		MeetDetails md=new MeetDetails();
		md.setRno(r);
		md.setMdate(date);
		md.setStime(sttime);
		md.setEtime(etime);
		md.setConfirm(confirm);
		
		
		
		
		int status1=0;
				status1=MeetingDeatilsDao.save(md);
		if(status1>=0){
			out.println("<h1>Meeting details saved successfully!</h1>");

		

		}else{
			out.println("Sorry! unable to save record");
		}
		
		out.close();
	}

}
