package com.meeting.servletss;


import java.io.IOException;

import java.io.PrintWriter;  
  
  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.MeetingDao;
import com.meeting.service.MeetingService;
  


@WebServlet("/MtServlet")
  
public class MtServlet extends HttpServlet { 
	 private MeetingDao dao;
	  
	  @Override
	public void init() throws ServletException {
		
	}
	  @Override
public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
		  Logger log=Logger.getLogger(MtServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
    
    PrintWriter out = response.getWriter();  
          
    String n1=request.getParameter("username");  
    String p1=request.getParameter("password");  
         MeetingService ms=new MeetingService();
         int r=ms.login(n1, p1);
    
	if(r!=0)
	{

		response.sendRedirect("meetservice.html");
	}
	else
	{
		out.println("invalid details");
	}
    out.close();  
    }  
}  