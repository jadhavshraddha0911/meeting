package com.meeting.servletss;

import java.io.IOException;
import java.io.PrintWriter;




import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.meeting.dao.ConfirmDao;

import com.meeting.dao.MeetingDeatilsDao;
import com.virtusa.bean.ConfirmBean;


@WebServlet("/ConfirmServlet")
public class ConfirmServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger log=Logger.getLogger(ConfirmServlet.class);
		  PropertyConfigurator.configure("log4j.properties");
		PrintWriter out=response.getWriter();
		String rno=request.getParameter("roomno");
		int id=Integer.parseInt(rno);
		String stat=request.getParameter("status");
		
		
		int status=0;
		status=MeetingDeatilsDao.room(id);
		
		if(status>0)
		{
			out.println("<p>Record Approved successfully!</p>");
		}
		else{
			out.println("Sorry! room number does not exist");
		}
		
		ConfirmBean cb=new ConfirmBean();
		cb.setRoomno(id);
		cb.setStatus(stat);
		int status1=0;
		
		status1=ConfirmDao.save(cb);
		
		
	}
}