package com.virtusa.bean;

public class RoomBean {

	private int roomno;
	private int newroom;
	private String roomname;
	private String status;
	
	public int getNewroom() {
		return newroom;
	}
	public void setNewroom(int newroom) {
		this.newroom = newroom;
	}
	public int getRoomno() {
		return roomno;
	}
	public void setRoomno(int n) {
		this.roomno = n;
	}
	public String getRoomname() {
		return roomname;
	}
	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
